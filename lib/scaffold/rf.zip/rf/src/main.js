/**
 * @file: main模块 
 * @author: treelite(c.xinle@gmail.com)
 */

define(function () {
    return {
        version: '${version}'
    };
});
